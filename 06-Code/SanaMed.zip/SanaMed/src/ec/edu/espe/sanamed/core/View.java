package ec.edu.espe.sanamed.core;

import javax.swing.JPanel;

/**
 *
 * @author 
 */
public abstract class View extends JPanel {
    public abstract void onReveal();
}
